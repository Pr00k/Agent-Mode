/// <reference types="vite/client" />

interface Window {
  __TAURI_INTERNALS__?: unknown;
  __TAURI__?: unknown;
}
